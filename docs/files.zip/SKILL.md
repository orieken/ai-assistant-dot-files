---
skill: contract-testing
version: 1.0.0
trigger: "/contract-testing [consumer] [provider]"
output: ".claude/feature-workspace/contract-test-[consumer]-[provider].md"
---

# Contract Testing Skill

## When to Use
Use this skill when:
- A feature introduces or modifies an API boundary between two services or bounded contexts
- The QA report contains a **Contract Testing Recommendation**
- Two different teams (or codebases) own either side of an integration
- You want to lock the shape of an API contract before it drifts

Do NOT use for:
- Internal method calls within the same bounded context
- APIs you fully own on both sides with no separate deployment
- Simple UI/backend calls within a monolith (use E2E tests instead)

## Context to Read First
Before starting, read:
- `.claude/feature-workspace/analysis.md` → identify the integration boundary
- `.claude/feature-workspace/architecture-notes.md` → confirm bounded context crossing and integration pattern
- `.claude/feature-workspace/qa-report.md` → find the Contract Testing Recommendation section
- The consumer codebase's existing API client (if it exists)
- The provider codebase's existing API spec or route definitions (if accessible)

## Core Concept: Consumer-Driven Contracts

**The consumer defines what it needs. The provider verifies it can meet that need.**

This is the opposite of provider-first API design. The consumer writes a Pact test saying "I expect this endpoint to return at least these fields in this shape." The provider runs that Pact against its actual implementation. If the provider changes the API in a way that breaks the consumer's contract, CI catches it before it reaches production.

Key terms:
- **Consumer**: the service that calls the API (makes HTTP requests)
- **Provider**: the service that serves the API (handles HTTP requests)
- **Pact**: the recorded contract — a JSON file describing interactions
- **Pact Broker**: optional service that stores and shares Pacts between teams (ask if your org uses one)

## Process

### Step 1 — Identify the Contract
Ask (one question at a time if interactive):
1. Which service is the **consumer** (makes the call)?
2. Which service is the **provider** (handles the call)?
3. What endpoint(s) are involved? (method + path)
4. What does the consumer actually need from the response? (not everything — just what it uses)
5. Is there a Pact Broker configured, or should Pacts be stored locally?

### Step 2 — Write the Consumer Pact Test
The contract test lives **with the consumer codebase**.

```typescript
// TypeScript / Pact-JS example
import { PactV3, MatchersV3 } from "@pact-foundation/pact";
const { like, eachLike, string, integer } = MatchersV3;

const provider = new PactV3({
  consumer: "[consumer-service-name]",
  provider: "[provider-service-name]",
  dir: "./pacts", // Pact JSON output directory
});

describe("Auth Service Contract", () => {
  it("returns user profile for a valid token", async () => {
    await provider
      .given("a valid authentication token exists")
      .uponReceiving("a request for user profile")
      .withRequest({
        method: "GET",
        path: "/api/v1/users/me",
        headers: { Authorization: like("Bearer token123") },
      })
      .willRespondWith({
        status: 200,
        body: {
          id: string("user-uuid"),
          email: string("user@example.com"),
          // Only include fields the consumer actually uses
          // Do NOT assert fields you don't use — reduces coupling
        },
      })
      .executeTest(async (mockServer) => {
        const client = new AuthApiClient(mockServer.url);
        const profile = await client.getMyProfile("token123");
        expect(profile.id).toBeDefined();
        expect(profile.email).toBeDefined();
      });
  });
});
```

**Pact minimalism rule**: Only assert the fields the consumer actually uses. Asserting the full response body couples the consumer to every provider change — including ones that don't affect the consumer.

### Step 3 — Write the Provider Verification Test
The provider verification lives **with the provider codebase**.

```typescript
// Provider verification — runs the real provider against the recorded Pact
import { Verifier } from "@pact-foundation/pact";

describe("Auth Service Provider Verification", () => {
  it("satisfies the consumer contract", async () => {
    await new Verifier({
      providerBaseUrl: "http://localhost:3000",
      pactUrls: ["./pacts/consumer-service-auth-service.json"],
      // or pactBrokerUrl if using a broker
      stateHandlers: {
        "a valid authentication token exists": async () => {
          // seed the provider's test database with this state
        },
      },
    }).verifyProvider();
  });
});
```

### Step 4 — Document the Contract
Write the output file at `.claude/feature-workspace/contract-test-[consumer]-[provider].md`.

### Step 5 — CI Integration Guidance
```markdown
## CI Integration

Consumer pipeline:
1. Run Pact consumer tests → generates pact JSON
2. Publish Pact to broker (if configured): `pact-broker publish ./pacts --broker-url $PACT_BROKER_URL`
3. Can-I-Deploy check before deploying: `pact-broker can-i-deploy --pacticipant [consumer] --broker-url $PACT_BROKER_URL`

Provider pipeline:
1. Run Pact provider verification against published Pacts
2. Publish verification results to broker
3. Can-I-Deploy check before deploying
```

## Output Format

Write `.claude/feature-workspace/contract-test-[consumer]-[provider].md`:

```markdown
# Contract Test: [Consumer] → [Provider]

## Integration Boundary
- **Consumer**: [service name + what it needs]
- **Provider**: [service name + endpoint(s) involved]
- **Context crossing**: [from bounded context X to bounded context Y]
- **Integration pattern**: Customer/Supplier | Conformist | ACL

## Contract Summary
| Interaction | Consumer assertion | Provider state |
|---|---|---|
| GET /api/v1/users/me | id, email fields present, status 200 | valid token exists |

## Test Files
- **Consumer test**: `[path/to/consumer.pact.spec.ts]`
- **Provider verification**: `[path/to/provider.pact.spec.ts]`
- **Pact JSON**: `[pacts/consumer-provider.json]`

## Pact Broker
- Configured: Yes | No
- URL: [if configured]

## CI Integration Steps
[from Step 5 above]

## What This Contract Does NOT Cover
[Things intentionally excluded from the contract and why]

## Drift Risk
[Fields or behaviors that are likely to change on the provider side — flag for monitoring]
```

## Guardrails

- **Consumer writes the contract, not the provider** — if the provider is defining what the consumer must accept, the direction is wrong
- **Assert only what you use** — every field asserted is a coupling point
- **State handlers must be realistic** — a provider state that can't be reproduced in CI is useless
- **Contract tests complement E2E, not replace them** — you still need acceptance tests for user-observable behavior
- **Don't Pact-test everything** — only boundaries between separately deployable or separately owned components

## Standalone Mode

If run without an existing `qa-report.md`, ask the user:
1. What are the two services? (consumer + provider)
2. What is the endpoint being contracted?
3. What does the consumer actually use from the response?

Then produce the consumer Pact test, provider verification, and output document.
