---
skill: mutation-check
version: 1.0.0
trigger: "/mutation-check [file-or-directory]"
output: ".claude/feature-workspace/mutation-report.md"
---

# Mutation Check Skill

## When to Use
Use this skill when:
- The QA report flags a critical path as **Low mutation confidence**
- You want to know if your test suite actually guards behavior (not just measures coverage)
- A feature touches core business logic, security paths, or data integrity rules
- Coverage is high but the team has low confidence in the tests

Do NOT use for:
- Test files themselves (mutating tests is recursive and unhelpful)
- Generated code or configuration files
- Simple CRUD with no business logic
- When you need fast feedback — mutation testing is slow; use it deliberately on critical paths

## Core Concept: What Mutation Testing Actually Tells You

Code coverage measures which lines were executed. Mutation testing measures whether your tests would catch a defect.

A **mutant** is a small deliberate change to the source code:
- Flip `>` to `>=`
- Change `&&` to `||`
- Remove a null check
- Flip a boolean return
- Change a status code constant

If your tests **kill** the mutant (fail when the mutation is present), the tests are actually guarding that behavior. If the mutant **survives** (all tests still pass), you have a coverage gap that matters.

**Mutation score** = killed mutants / total mutants. Aim for 80%+ on critical paths. 100% is rarely worth the cost.

## Tool Selection

| Language | Tool | Install |
|---|---|---|
| TypeScript / JavaScript | Stryker | `npx stryker init` |
| Python | mutmut | `pip install mutmut --break-system-packages` |
| Go | go-mutesting | `go install github.com/zimmski/go-mutesting/cmd/go-mutesting@latest` |
| Java | PIT (Pitest) | Maven/Gradle plugin |

## Process

### Step 1 — Identify Critical Paths
Before running mutation testing (which is slow), identify the high-value targets:
- Business rule enforcement (pricing, permissions, rate limits, state machines)
- Security logic (auth checks, input validation, token handling)
- Data integrity rules (validation, constraint enforcement)
- Error handling paths (what happens when dependencies fail)

Don't mutate everything. Be deliberate.

### Step 2 — Run Mutation Testing

**TypeScript (Stryker):**
```bash
# Initialize Stryker config if not present
npx stryker init

# Run against specific files
npx stryker run --mutate "src/auth/rate-limit.service.ts"

# Run against a directory
npx stryker run --mutate "src/auth/**/*.ts"
```

Stryker config (`stryker.config.json`):
```json
{
  "mutate": ["src/auth/rate-limit.service.ts"],
  "testRunner": "jest",
  "reporters": ["html", "clear-text", "json"],
  "coverageAnalysis": "perTest"
}
```

**Python (mutmut):**
```bash
# Run against a specific file
mutmut run --paths-to-mutate src/auth/rate_limit.py

# Show surviving mutants
mutmut results

# Show what a surviving mutant looks like
mutmut show [mutant-id]
```

**Heuristic analysis (when tools unavailable):**
If mutation tools can't be installed or run, perform manual mutation reasoning:
1. Read the critical path code
2. For each conditional expression, null check, comparison, and status code — ask: "if I changed this, would any test fail?"
3. If the answer is "no" or "maybe" — that's a coverage gap
4. Document the gap with a specific test suggestion

### Step 3 — Interpret Results

**Killed mutant** (good): your tests caught the defect — the behavior is guarded
**Survived mutant** (needs attention): tests passed even though behavior changed — coverage gap

For each surviving mutant, determine:
- **Is this critical?** — does the mutant represent a real defect scenario?
- **Is there already a test?** — if yes, the test is too broad; add a targeted assertion
- **Should we add a test?** — if no focused test exists, write one

### Step 4 — Write Targeted Tests for Surviving Mutants

For each critical survived mutant, write a focused test:
```typescript
// Mutant survived: `failedAttempts >= maxAttempts` was changed to `failedAttempts > maxAttempts`
// The test suite didn't catch it — no test verifies the exact threshold

test("account locks on the 5th failed attempt, not the 6th", async () => {
  // 4 attempts — should NOT be locked
  for (let i = 0; i < 4; i++) {
    await loginPage.attemptLogin("user@test.com", "wrong");
  }
  expect(await loginPage.isLocked()).toBe(false);

  // 5th attempt — should NOW be locked
  await loginPage.attemptLogin("user@test.com", "wrong");
  expect(await loginPage.isLocked()).toBe(true);
});
```

The test name should explicitly describe the boundary condition — not just "test the rate limit."

### Step 5 — Document and Report

Write `.claude/feature-workspace/mutation-report.md`.

## Output Format

Write `.claude/feature-workspace/mutation-report.md`:

```markdown
# Mutation Report: [Feature / File]

## Tool Used
Stryker | mutmut | go-mutesting | Heuristic Analysis (tools unavailable)

## Files Analyzed
- `src/auth/rate-limit.service.ts` — [why this was selected as critical path]

## Summary
| Metric | Value |
|---|---|
| Total mutants | N |
| Killed | N (X%) |
| Survived | N (Y%) |
| Timeout | N |
| Target score | 80% on critical paths |
| Assessment | ✅ Sufficient / ⚠️ Gaps found |

## Surviving Mutants — Critical

### [Mutant ID or description]
**File**: `path/to/file.ts` line X
**Mutation applied**: [what was changed — e.g., `>=` → `>`]
**Why it survived**: [no test verifies this specific boundary]
**Risk**: High / Medium / Low
**Targeted test written**: ✅ `[test name]` in `[file]` / ❌ [reason not written]

## Surviving Mutants — Non-Critical
[List survived mutants that don't represent real defect scenarios — with justification for ignoring]

## New Tests Written
- `[test name]`: [what boundary it now guards]

## Recommendations
- [ ] Add Stryker to CI for `src/auth/` directory (run on changed files only using `--since`)
- [ ] Mutation score threshold: 80% on critical paths — add to `stryker.config.json` as `thresholds.break: 60`
- [ ] Re-run after next modification to [specific file]

## What Was Not Analyzed
[Files or paths excluded and why]
```

## CI Integration

Once mutation testing proves valuable on a path, add it to CI:

```json
// stryker.config.json — CI-optimized
{
  "mutate": ["src/auth/**/*.ts"],
  "testRunner": "jest",
  "coverageAnalysis": "perTest",
  "thresholds": {
    "high": 80,
    "low": 60,
    "break": 50
  },
  "incremental": true,
  "reporters": ["json", "clear-text"]
}
```

Run only on changed files to keep CI times reasonable:
```bash
npx stryker run --since HEAD~1
```

## Guardrails

- **Mutation testing is slow** — run deliberately on critical paths, not as a default step
- **Not every survived mutant is a problem** — some are equivalent mutants (the change doesn't alter observable behavior). Document your reasoning for ignoring them
- **Heuristic analysis is always available** — if tools can't run, reason manually through the conditionals
- **The goal is targeted tests, not 100% mutation score** — a few well-placed tests are more valuable than chasing a number

## Standalone Mode

If run without an existing `qa-report.md`, ask:
1. Which file or directory is the critical path to analyze?
2. Which language and test runner are in use?
3. Are mutation testing tools installed, or should I do heuristic analysis?

Then run the analysis, write targeted tests for critical survived mutants, and produce the mutation report.
